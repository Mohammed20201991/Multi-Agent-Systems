#! /usr/bin/env python

from comm import Communicator
from util import Graph, Timer
import threading
from sets import Set
import xml.etree.ElementTree as etree 
from global_vars import * #@UnusedWildImport
import time
from algorithms import Action
import pprint
import sys


class Agent(threading.Thread, Communicator, Graph):

    
    def __init__(self, name, password, number, dummy = False, buffer = []):
        threading.Thread.__init__(self)
        self.dummy = dummy
        self.number = number
        self.team_name = ''
        self.buffer = buffer
        self.name = name
        self.info = {}
        self.rounds = 0
        self.step = 0
        self.runtime = 0
        self.money = 0
        self.type = ''
        self.id = '0'
        self.frontier = Set()
        self.owned = Set()
        self.expand = None
        self.password = password
        self.action = etree.fromstring('''<?xml version="1.0" encoding="UTF-8"?><message type="action"><action id="" type="goto" /></message>''')
        self.team = team
        self.last_goal = None

        ## GRAPH STUFF
        
        self.known_edges = set()
        self.unknown_edges = set()
        self.vertices = {}
        self.vertex_to_agent = {}
        self.agent_to_vertex = {}
        
        ## SHARED PERCEPTS STUFF
         
        self.inspect_percepts = []
        self.edge_percepts = []
        self.probe_percepts = []
        self.vertex_percepts = []
        self.entity_percepts = []
                
    def get_info(self):
        return str(self.info) + ' name ' + self.name 
        
    def get_position(self):
        return self.vertices[self.info['position']]
    
          
    def initialize(self, message):
        
        ## reset all variables
        
        info = message.find('simulation') 
        self.type = info.attrib['role']
        SHARED[AGENTS][self.name] = (self, self.type) 
        if self.type == REP:
            if not self.name in SHARED[REPS]:
                SHARED[REPS].append(self.name)
            
        print (self.name,'Simulation started, total edges:', info.attrib['edges'], 'total vertices:', info.attrib['vertices'], 'steps:',info.attrib['steps'])
        
        if self.number == 0:  
                if DRAW:
                    Timer(2,self).start()
    
    def get_affordable_neighbour(self):
        
        neigh = None
        best = 100
        for n, value in self.get_position().neighbours.copy().iteritems():
            if value < best:
                neigh = n
            
        if best <= self.info['maxEnergyDisabled'] or best == WEIGHT:
            return neigh
        else:
            return None
    
    def handle_last_action(self):
        if self.info['lastActionResult'] != 'successful':
            if 'wrong' in self.info['lastActionResult']:
                print ('OBS OBS', self.name, self.info['lastActionResult'], ' : ', self.info['lastAction'])
            else:
                print (self.name, self.step,  self.info['lastActionResult'], ' : ', self.info['lastAction'])
                
    def recharge_rate(self):
        return int(self.info['maxEnergy'])/2
    def is_hit(self):
        return self.info['health'] != self.info['maxHealth']
    def is_disabled(self):
        return self.info['health'] == '0'    
    def rep_in_neighbourhood(self):
        for v in self.get_position().neighbours.iterkeys():
            if v.id in self.vertex_to_agent and (SHARED[REPS][0] in self.vertex_to_agent[v.id] or SHARED[REPS][1] in self.vertex_to_agent[v.id]):
                return True
        return False
     
    def repair_randomly(self):
            agent = None
            for a in self.vertex_to_agent[self.info['position']]:
                if a in SHARED[DISABLED] and not a  == self.name:
                    agent = a
                    if SHARED[AGENTS][a][1] == SAB:
                        break

            if not agent is None:
                return [Action(self.name + '_repairing_randomly_', REPAIR, arg=agent)]  
            else:
                return None
               
    def handle_disabled(self):
        
        if self.type == REP:
            rep = filter(lambda x: x != self.name and x in SHARED[DISABLED] and SHARED[AGENTS][x][1] == REP ,self.vertex_to_agent[self.info['position']])
            if rep:
                return [Action(self.name + '_repairing_collegue_', REPAIR, arg=rep[0])] 
                
        if self.is_disabled():
            
            goals = self.n_get_repairer(self.get_position()) 
            if goals:
                if self.type == REP and len(goals[0].path) > 1:
                    res = self.repair_randomly()
                    if not res is None:
                        return res
                
                if (len(goals[0].path) > 1 and not self.rep_in_neighbourhood()) or (len(goals[0].path) == 1 and SHARED[AGENTS][goals[0].rep][0].info['energy'] < goals[0].cost):
#                    print self.name, 'moving to repairer', goals[0].path[0].id
                    return [goals[0]] 
                ## if both repairers are disabled, let one go all the way
                elif self.type == REP and SHARED[REPS][0] in SHARED[DISABLED] and SHARED[REPS][1] in SHARED[DISABLED]:
                    if (SHARED[REPS][0] > SHARED[REPS][1] and self.name == SHARED[REPS][0]) or (SHARED[REPS][1] > SHARED[REPS][0] and self.name == SHARED[REPS][1]):
                        print (self.name, 'both repairers are out, going all the way')
                        return [goals[0]]  
                     
                else:
#                    print self.name, 'repairer in neighbourhood, recharging'
                    return [Action(self.name + '_' + RECHARGE, RECHARGE)]
            else:
                n = self.get_affordable_neighbour()
                if n is None:
                    print (self.name, 'no repairers found, nowhere to go, recharging')
                    return [Action(self.name + '_' + RECHARGE, RECHARGE)]
                else:
                    print (self.name, 'no repairers found, escaping randomly')
                    return [Action(self.name + '_' + GOTO, GOTO, n, path = [n], length = self.get_position().neighbours[n] )]
        
        elif self.type == REP:
            return self.repair_randomly()      
        
        return None
    
    def reset(self):
        reset()
        self.__init__(self.name, self.password, self.number, buffer = self.buffer)
    def run(self):
        self.connect(self.password)
            
        while True:     
            self.t = time.time()                   
            message = self.receive()
            receive_time = time.time() - self.t
            self.t = time.time()
          
            message_type = message.get('type')            
            
            if message_type == 'sim-start':
                if self.dummy:
                    pass
                else:
                    self.initialize(message)
                    print (self.type)
                continue
            elif message_type == 'sim-end':
                print ('Simulation ended')
                self.reset()
                continue
            elif message_type == 'bye':
                print (self.name, 'Server disconnecting')
                self.stop()
                
            self.runtime = self.runtime + 1
            percepts = message.find('perception')
            self.handle_percept(percepts)
            if self.dummy:
                self.send_action('skip')
                continue  
            
                
            if SHARED[READY][0] != self.step:
                SHARED[READY] = (self.step, Set())
            while len(SHARED[READY][1]) < 10:
                SHARED[READY][1].add(self.name)
                time.sleep(WAIT_TIME)
                
            self.handle_team_percepts()
                
            time1 = time.time()-self.t
            
            if self.number == 1:
                # reconsider starting point every x step
                if self.expand is None or self.step % 5 == 0:
                    self.expand = self.find_init()
                    
                self.calc_expand(True)
                if len(self.frontier) < 6:
                    self.calc_expand(False)
                    
                    
            ## play against a not moving team b  
          

            self.handle_last_action()
            g1 = time.time() 
            
            goals = self.handle_disabled()
            
            if goals is None:
                goals = self.get_goals(self.get_position()) 
                
            
            g2 = time.time()-g1

            a1 = time.time()    
            
            target = self.do_auction(goals)
            
            a2 = time.time()-a1
            
            self.do_action(target)
                
            time2 = time.time()-self.t
            
            if time2 > 1.5:
                print (self.name, self.type, self.step,  'p-time ', round(time1,3),  'r-time', round(receive_time,3), 'a-time', round(a2,3), 'g-time', round(g2,3) , 't-time', round(time2,3))
              
        
    def should_recharge(self, action):
        total_cost = action.length + COSTS[action.type]
        
        # we can go all way without recharging
        if total_cost < int(self.info['energy']):
            return False
        # we can't make a single step without recharging
        if action.path and self.get_position().neighbours[action.path[0]] > int(self.info['energy']):
            return True
        if action.path and self.get_position().neighbours[action.path[0]] == WEIGHT and int(self.info['energy']) < 10:
            return True
        # we are below recharge rate and may just as well recharge
        a = not self.is_disabled() and int(self.info['energy']) <= self.recharge_rate()
        b = self.is_disabled() and int(self.info['energy']) <= 0.7*int(self.info['maxEnergyDisabled'])
        
        if a or b:
            return True
        else:
            return False
    
    def do_action(self, action):
        if action.type == RECHARGE or self.should_recharge(action):
            self.send_action(RECHARGE)
            return  
        
        health = int(self.info['maxHealth'])
        strength = int(self.info['strength'])
        
        if DO_BUY and self.type == SAB and not self.is_disabled() and self.money >= 4 and self.runtime > RUNTIME and not self.has_sab():
            if health < 7:
                self.send_action(BUY, HEALTH)
                return
            elif strength < 6:
                self.send_action(BUY, STRENGTH)
                return
                
            
            
        if not action.vertex is None and action.vertex.id != self.info['position']:
            ## agents survey on the way if they are not on their way to repair
#            if not (action.type == REPAIR or action.type == ATTACK) and not self.is_disabled() and not self.get_position().is_surveyed():
#                self.send_action(SURVEY)
#            else:    
#                self.send_action(GOTO, action.path[0].id)
            self.send_action(GOTO, action.path[0].id)
            self.last_goal = action.path[0]
            # print self.name, type, 'pos', self.info['position'], 'target', target.vertex.id, 'goto', target.path[0].id
        elif action.type == NOOP:
            if self.type == SEN and self.has_sab():
                self.send_action(PARRY)
            elif not self.get_position().is_surveyed():
                self.send_action(SURVEY)
            elif self.info['maxEnergy'] != self.info['energy']:
                self.send_action(RECHARGE)
            else:
                self.send_action(RECHARGE)
                
            
        else:
            if action.arg is None: 
                self.send_action(action.type)
            else:
                self.send_action(action.type, action.arg)
            # print self.name, type, self.info['position']
    
    
    def has_sab(self):
        match = self.has_opponent(self.get_position())      
        pot_sab = False
        for agent in match:
            if not agent in SHARED[DIS_OPP] and (not agent in SHARED[OPPONENTS] or SHARED[OPPONENTS][agent] == 'Saboteur'):
                pot_sab = True
                break
        return pot_sab
    
    def filter_goals(self, goals, type, new_data):
        
        if type == REP:
            action = REPAIR
        elif type == EXP:
            action = PROBE
        elif type == SAB:
            action = ATTACK  
        else:
            return (None, goals)
        
        specialGoals = 0
        pro = None
        for a in goals:
            if a.type == action:
                specialGoals = specialGoals + 1
                pro = a
        if specialGoals > 1:
            goals = filter(lambda x: x.type == action, goals)
        elif specialGoals == 1:
            if pro.goal in new_data and new_data[pro.goal][1] <= pro.cost:
                goals = filter(lambda x: x.type != action, goals)
            else:
                new_data[pro.goal] = (self.name, pro.cost)
                return (pro, goals)
        
        return (None, goals)  
        
    def do_auction(self, goals):
        if SHARED[AUCTION][0] != self.step:
            SHARED[AUCTION] = (self.step, {})
         
        
        new_data = SHARED[AUCTION][1]
        target = None
        i = 0
        while len(new_data) < 10 and i < MAX_ROUNDS:
#            print new_data
            i = i+1
            time.sleep(WAIT_TIME)

            ## make sure repairs, attacks and probes are prioritized                    
            t, goals = self.filter_goals(goals, self.type, new_data)
            if t is not None:
                target = t
                continue
            #Let MAX_BEN be one larger than biggest cost 
            max = 0
            for g in goals:
                if g.cost > max:
                    max = g.cost
            MAX_BEN = max + 1
                    
                    
            has_vertex = False
            
            for vertex, (name, bid)  in new_data.items(): #@UnusedVariable
                if name == self.name:
                    has_vertex = True
            
            if has_vertex:
                continue
    
            scores = [] 

            for action in goals:
                if action.goal in new_data:
                    current_bid = new_data[action.goal][1]
                    scores.append((action, MAX_BEN - action.cost - current_bid, current_bid))
                else:
                    scores.append((action, MAX_BEN - action.cost, 0))
    
            scores = sorted(scores, lambda x,y: cmp(y[1], x[1]))

            current = scores[0][0].goal
            if not has_vertex: 
                if len(goals) == 1:
                    bid = 1
                else:
                    bid = bid = scores[0][2] + scores[0][1] - scores[1][1] + epsilon
                new_data[current] = (self.name, bid)
                target = scores[0][0]

        if i == MAX_ROUNDS:
            print (self.name, self.type, 'max rounds exceeded in auction')
#            print new_data
            
            
        if self.number == 1:
            print (self.step)
            pprint.pprint(new_data)
            print ('')
            
        return target


start = 1   
n = 10


def start_team():
    for i, a in enumerate(team):
        agent = Agent(a, PASSWORD, i)
        agent.daemon = True
        agent.start()
        SHARED[AGENTS][a] = (agent, '')

def start_dummy(team_name):
    for i in range(start,n+1):
        name = team_name+str(i)

        agent = Agent(name,'1', i, True)
        agent.daemon = True
        agent.start()

team = []
DUMMY = False
if len(sys.argv) < 2:
    print ('give one argument: a for team a, b for team b, d for team a with dummy agents, c for competition team')
    sys.exit(0)
elif sys.argv[1] == 'a':
    team = A
elif sys.argv[1] == 'b':
    team = B
elif sys.argv[1] == 'd': 
    team = A
    DUMMY = True
    
elif sys.argv[1] == 'c':
    team = C
else:
    print ('argument not understood, exiting')
    sys.exit(0)

if len(sys.argv) > 2:
    DO_BUY = True
else:
    DO_BUY = False
     
if DUMMY:
    start_dummy('b')
start_team()  


while SHARED[RUNNING]:
    time.sleep(2)
print ('')
print ('Stopped')
