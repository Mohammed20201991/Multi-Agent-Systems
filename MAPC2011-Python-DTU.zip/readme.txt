﻿Multi-Agent Programming Contest 2011 - Python-DTU

Participants from DTU Informatics:

- Jørgen Villadsen - Supervisor - Associate professor

- Mikko Berggren Ettienne

- Steen Vester 

Department of Informatics and Mathematical Modelling
Technical University of Denmark (DTU)

http://www.imm.dtu.dk/~jv/MAS

----------

Start massim server - massim-2011-1.0.2/massim/scripts/startServer.sh

Run agent.py with Python 2.6+
